import 'dotenv/config';

function requireEnv(key: string): string {
  const value = process.env[key];
  if (!value) throw new Error(`Missing required environment variable: ${key}`);
  return value;
}

function optionalEnv(key: string, fallback: string): string {
  return process.env[key] ?? fallback;
}

export const config = {
  app: {
    env: optionalEnv('NODE_ENV', 'development'),
    port: parseInt(optionalEnv('PORT', '3000'), 10),
    apiPrefix: optionalEnv('API_PREFIX', '/api/v1'),
    isDev: optionalEnv('NODE_ENV', 'development') === 'development',
    isProd: process.env.NODE_ENV === 'production',
    isTest: process.env.NODE_ENV === 'test',
  },
  db: {
    url:
      process.env.NODE_ENV === 'test'
        ? requireEnv('DATABASE_URL_TEST')
        : requireEnv('DATABASE_URL'),
  },
  auth: {
    jwtSecret: requireEnv('JWT_SECRET'),
    jwtAccessExpiresIn: optionalEnv('JWT_ACCESS_EXPIRES_IN', '15m'),
    jwtRefreshSecret: requireEnv('JWT_REFRESH_SECRET'),
    jwtRefreshExpiresIn: optionalEnv('JWT_REFRESH_EXPIRES_IN', '7d'),
    bcryptRounds: parseInt(optionalEnv('BCRYPT_ROUNDS', '12'), 10),
  },
  cors: {
    origins: optionalEnv('CORS_ORIGINS', 'http://localhost:3001').split(','),
  },
  rateLimit: {
    windowMs: parseInt(optionalEnv('RATE_LIMIT_WINDOW_MS', '900000'), 10),
    max: parseInt(optionalEnv('RATE_LIMIT_MAX', '100'), 10),
    authMax: parseInt(optionalEnv('AUTH_RATE_LIMIT_MAX', '10'), 10),
  },
  cookie: {
    secret: optionalEnv('COOKIE_SECRET', 'dev-cookie-secret'),
  },
  logging: {
    level: optionalEnv('LOG_LEVEL', 'info'),
  },
  s3: {
    region: optionalEnv('AWS_REGION', 'us-east-1'),
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    bucketName: process.env.S3_BUCKET_NAME,
    maxFileSizeMb: parseInt(optionalEnv('MAX_FILE_SIZE_MB', '10'), 10),
  },
  redis: {
    url: optionalEnv('REDIS_URL', 'redis://localhost:6379'),
  },
  email: {
    host: optionalEnv('SMTP_HOST', 'localhost'),
    port: parseInt(optionalEnv('SMTP_PORT', '587'), 10),
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
    from: optionalEnv('EMAIL_FROM', 'noreply@myapp.com'),
  },
} as const;

export type Config = typeof config;
