import { Request } from 'express';
import { Role } from '@prisma/client';

// ── Auth ──────────────────────────────────────────────

export interface JwtPayload {
  sub: string; // userId
  email: string;
  role: Role;
  type: 'access' | 'refresh';
}

export interface AuthenticatedUser {
  id: string;
  email: string;
  role: Role;
}

export interface AuthenticatedRequest extends Request {
  user: AuthenticatedUser;
  requestId: string;
}

// ── Pagination ────────────────────────────────────────

export interface PaginationQuery {
  page?: number;
  limit?: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  search?: string;
}

export interface PaginatedResult<T> {
  data: T[];
  meta: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
    hasNext: boolean;
    hasPrev: boolean;
  };
}

// ── API Response ──────────────────────────────────────

export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  message?: string;
  error?: {
    code: string;
    message: string;
    details?: unknown;
  };
  meta?: Record<string, unknown>;
}

// ── User DTOs ─────────────────────────────────────────

export interface CreateUserDto {
  email: string;
  password: string;
  name: string;
}

export interface LoginDto {
  email: string;
  password: string;
}

export interface UserResponseDto {
  id: string;
  email: string;
  name: string;
  role: Role;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

// ── Post DTOs ─────────────────────────────────────────

export interface CreatePostDto {
  title: string;
  content?: string;
  published?: boolean;
}

export interface UpdatePostDto {
  title?: string;
  content?: string;
  published?: boolean;
  version: number; // optimistic concurrency
}

export interface PostResponseDto {
  id: string;
  title: string;
  content: string | null;
  published: boolean;
  version: number;
  authorId: string;
  author?: UserResponseDto;
  createdAt: Date;
  updatedAt: Date;
}

// ── Post Filters ──────────────────────────────────────

export interface PostFilters extends PaginationQuery {
  published?: boolean;
  authorId?: string;
}
