import { motion } from 'framer-motion';
import { AlertTriangle, Info, AlertCircle } from 'lucide-react';
import { alertsData } from '@/lib/mockData';
import { useApp } from '@/contexts/AppContext';
import { t } from '@/lib/i18n';

const severityConfig = {
  LOW: { icon: Info, color: 'text-info', bg: 'bg-info/10', border: 'border-info/30' },
  MEDIUM: { icon: AlertCircle, color: 'text-warning', bg: 'bg-warning/10', border: 'border-warning/30' },
  HIGH: { icon: AlertTriangle, color: 'text-anomaly', bg: 'bg-anomaly/10', border: 'border-anomaly/30' },
};

export default function AlertsPanel({ compact = false }: { compact?: boolean }) {
  const { language } = useApp();
  const alerts = compact ? alertsData.slice(0, 4) : alertsData;

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }} className="glass-card p-5">
      <h2 className="text-lg font-semibold text-foreground mb-4">{t('alertsPanel', language)}</h2>
      <div className="space-y-3">
        {alerts.map((alert, i) => {
          const cfg = severityConfig[alert.severity];
          const Icon = cfg.icon;
          return (
            <motion.div
              key={alert.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.05 }}
              className={`flex items-start gap-3 p-3 rounded-lg border ${cfg.bg} ${cfg.border} ${!alert.read ? 'ring-1 ring-primary/20' : ''}`}
            >
              <Icon className={`h-4 w-4 mt-0.5 shrink-0 ${cfg.color}`} />
              <div className="flex-1 min-w-0">
                <p className="text-sm text-foreground">{alert.message}</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className={`text-[10px] font-bold uppercase ${cfg.color}`}>{t(alert.severity.toLowerCase(), language)}</span>
                  <span className="text-[10px] text-muted-foreground">• {alert.department}</span>
                  <span className="text-[10px] text-muted-foreground">• {alert.timestamp}</span>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
}
