import { Bell, LogOut } from 'lucide-react';
import { motion } from 'framer-motion';
import { useApp } from '@/contexts/AppContext';
import { t } from '@/lib/i18n';
import { alertsData } from '@/lib/mockData';
import { SidebarTrigger } from '@/components/ui/sidebar';

export default function HeartbeatHeader() {
  const { user, language, logout } = useApp();
  const unreadCount = alertsData.filter(a => !a.read).length;

  return (
    <header className="h-16 flex items-center justify-between px-4 md:px-6 border-b border-border glass-card sticky top-0 z-30">
      <div className="flex items-center gap-3">
        <SidebarTrigger className="text-muted-foreground hover:text-foreground" />
        <div className="flex items-center gap-2">
          <HeartbeatSVG />
          <div className="hidden sm:block">
            <h1 className="text-sm font-bold gradient-text">{t('hospitalName', language)}</h1>
            <p className="text-[10px] text-muted-foreground">{t('commandCenter', language)}</p>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <motion.div whileHover={{ scale: 1.1 }} className="relative cursor-pointer p-2 rounded-lg hover:bg-accent transition-colors">
          <Bell className="h-5 w-5 text-muted-foreground" />
          {unreadCount > 0 && (
            <span className="absolute -top-0.5 -right-0.5 h-4 w-4 rounded-full bg-anomaly text-[10px] font-bold flex items-center justify-center text-primary-foreground">
              {unreadCount}
            </span>
          )}
        </motion.div>

        {user && (
          <div className="flex items-center gap-2">
            <div className="hidden md:block text-right">
              <p className="text-xs font-medium text-foreground">{user.name}</p>
              <p className="text-[10px] text-muted-foreground capitalize">{t(user.role === 'departmentHead' ? 'departmentHead' : user.role === 'floorSupervisor' ? 'floorSupervisor' : 'ceo', language)}</p>
            </div>
            <motion.button whileHover={{ scale: 1.1 }} onClick={logout} className="p-2 rounded-lg hover:bg-accent transition-colors text-muted-foreground hover:text-destructive" title={t('signOut', language)}>
              <LogOut className="h-4 w-4" />
            </motion.button>
          </div>
        )}
      </div>
    </header>
  );
}

function HeartbeatSVG() {
  return (
    <svg width="48" height="24" viewBox="0 0 48 24" className="heartbeat-line">
      <polyline
        points="0,12 8,12 12,4 16,20 20,8 24,16 28,12 32,12 36,6 40,18 44,12 48,12"
        fill="none"
        stroke="hsl(var(--primary))"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
