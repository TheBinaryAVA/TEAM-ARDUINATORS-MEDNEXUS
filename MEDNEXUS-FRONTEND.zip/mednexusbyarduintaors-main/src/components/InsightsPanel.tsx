import { motion } from 'framer-motion';
import { Brain, CheckCircle2, ChevronRight } from 'lucide-react';
import { insightsData } from '@/lib/mockData';
import { useApp } from '@/contexts/AppContext';
import { t } from '@/lib/i18n';

export default function InsightsPanel({ compact = false }: { compact?: boolean }) {
  const { language } = useApp();
  const data = compact ? insightsData.slice(0, 2) : insightsData;

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7 }} className="glass-card p-5">
      <div className="flex items-center gap-2 mb-4">
        <Brain className="h-5 w-5 text-primary" />
        <h2 className="text-lg font-semibold text-foreground">{t('aiInsights', language)}</h2>
      </div>
      <div className="space-y-4">
        {data.map((item, i) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="p-4 rounded-lg border border-border bg-card/50"
          >
            <div className="flex items-start justify-between mb-2">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-primary bg-accent px-2 py-0.5 rounded-full">{item.category}</span>
              <span className="text-[10px] font-mono text-muted-foreground">{t('confidence', language)}: {item.confidence}%</span>
            </div>
            <p className="text-sm text-foreground mb-3">{item.insight}</p>
            <div className="space-y-1.5">
              {item.actions.map((action, j) => (
                <div key={j} className="flex items-start gap-2 text-xs text-muted-foreground">
                  <CheckCircle2 className="h-3.5 w-3.5 text-success shrink-0 mt-0.5" />
                  <span>{action}</span>
                </div>
              ))}
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
