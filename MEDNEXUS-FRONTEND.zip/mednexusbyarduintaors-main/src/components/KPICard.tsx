import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, AlertTriangle } from 'lucide-react';
import { LineChart, Line, ResponsiveContainer } from 'recharts';
import { KPIData } from '@/lib/mockData';
import { useApp } from '@/contexts/AppContext';
import { t } from '@/lib/i18n';

export default function KPICard({ kpi, index }: { kpi: KPIData; index: number }) {
  const { language } = useApp();
  const sparkData = kpi.sparkline.map((v, i) => ({ v, i }));
  const isPositive = kpi.deviation >= 0;
  const deviationColor = isPositive ? 'text-success' : 'text-anomaly';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.4 }}
      whileHover={{ scale: 1.02, y: -2 }}
      className={`glass-card p-4 md:p-5 relative overflow-hidden group ${kpi.isAnomaly ? 'anomaly-pulse border-anomaly/40' : 'kpi-glow'}`}
    >
      {kpi.isAnomaly && (
        <div className="absolute top-3 right-3">
          <AlertTriangle className="h-4 w-4 text-anomaly" />
        </div>
      )}

      <div className="flex justify-between items-start mb-2">
        <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
          {t(kpi.i18nKey, language)}
        </p>
        <span className={`text-[10px] font-mono font-semibold flex items-center gap-0.5 ${deviationColor}`}>
          {isPositive ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
          {isPositive ? '+' : ''}{kpi.deviation}%
        </span>
      </div>

      <div className="flex items-end justify-between">
        <div>
          <span className="text-2xl md:text-3xl font-bold text-foreground">{kpi.value}</span>
          <span className="text-sm text-muted-foreground ml-1">{kpi.unit}</span>
        </div>
        <div className="w-20 h-10 opacity-60 group-hover:opacity-100 transition-opacity">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={sparkData}>
              <Line type="monotone" dataKey="v" stroke="hsl(var(--primary))" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="mt-2 flex items-center gap-2">
        <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${Math.min((kpi.value / kpi.target) * 100, 100)}%` }}
            transition={{ delay: index * 0.1 + 0.3, duration: 0.6 }}
            className="h-full rounded-full"
            style={{ background: 'var(--gradient-primary)' }}
          />
        </div>
        <span className="text-[10px] text-muted-foreground font-mono">{kpi.target}{kpi.unit}</span>
      </div>
    </motion.div>
  );
}
