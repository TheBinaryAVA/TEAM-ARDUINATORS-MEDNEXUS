import { useState } from 'react';
import { motion } from 'framer-motion';
import { Send, Loader2, RefreshCw, CheckCircle, XCircle } from 'lucide-react';
import { useApp } from '@/contexts/AppContext';
import { t } from '@/lib/i18n';
import { departments } from '@/lib/mockData';

interface FormData {
  date: string;
  department: string;
  bedOccupancy: string;
  opdWaitTime: string;
  billingCollection: string;
  labTAT: string;
  nps: string;
}

export default function N8nForm() {
  const { language } = useApp();
  const [form, setForm] = useState<FormData>({
    date: new Date().toISOString().split('T')[0],
    department: '',
    bedOccupancy: '',
    opdWaitTime: '',
    billingCollection: '',
    labTAT: '',
    nps: '',
  });
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [response, setResponse] = useState<Record<string, string> | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  const validate = (): boolean => {
    if (!form.department) return false;
    const nums = [form.bedOccupancy, form.opdWaitTime, form.billingCollection, form.labTAT, form.nps];
    return nums.every(n => n !== '' && !isNaN(Number(n)));
  };

  const handleSubmit = async () => {
    if (!validate()) return;
    setStatus('loading');
    setResponse(null);
    setErrorMsg('');

    try {
      const res = await fetch('https://hospitalkpi.app.n8n.cloud/webhook-test/hospital-kpi-dashboard-updated', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          date: form.date,
          department: form.department,
          bed_occupancy: Number(form.bedOccupancy),
          opd_wait_time: Number(form.opdWaitTime),
          billing_collection: Number(form.billingCollection),
          lab_tat: Number(form.labTAT),
          nps: Number(form.nps),
        }),
      });

      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      if (!data || (typeof data === 'object' && Object.keys(data).length === 0)) {
        throw new Error('Empty response');
      }
      const parsed: Record<string, string> = {};
      if (typeof data === 'object') {
        Object.entries(data).forEach(([k, v]) => { parsed[k] = String(v); });
      }
      setResponse(parsed);
      setStatus('success');
    } catch (err: any) {
      setErrorMsg(err.message || 'Unknown error');
      setStatus('error');
    }
  };

  const inputClass = "w-full px-3 py-2 rounded-lg bg-secondary border border-border text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all";
  const labelClass = "text-xs font-medium text-muted-foreground mb-1 block";

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-card p-5">
      <h2 className="text-lg font-semibold text-foreground mb-4">{t('submitKPI', language)}</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div>
          <label className={labelClass}>{t('date', language)}</label>
          <input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} className={inputClass} />
        </div>
        <div>
          <label className={labelClass}>{t('department', language)}</label>
          <select value={form.department} onChange={e => setForm({ ...form, department: e.target.value })} className={inputClass}>
            <option value="">Select...</option>
            {departments.map(d => <option key={d} value={d}>{d}</option>)}
          </select>
        </div>
        <div>
          <label className={labelClass}>{t('bedOccupancy', language)} (%)</label>
          <input type="number" value={form.bedOccupancy} onChange={e => setForm({ ...form, bedOccupancy: e.target.value })} className={inputClass} placeholder="85" />
        </div>
        <div>
          <label className={labelClass}>{t('opdWaitTime', language)} (min)</label>
          <input type="number" value={form.opdWaitTime} onChange={e => setForm({ ...form, opdWaitTime: e.target.value })} className={inputClass} placeholder="15" />
        </div>
        <div>
          <label className={labelClass}>{t('billingCollection', language)} (%)</label>
          <input type="number" value={form.billingCollection} onChange={e => setForm({ ...form, billingCollection: e.target.value })} className={inputClass} placeholder="95" />
        </div>
        <div>
          <label className={labelClass}>{t('labTAT', language)} (min)</label>
          <input type="number" value={form.labTAT} onChange={e => setForm({ ...form, labTAT: e.target.value })} className={inputClass} placeholder="45" />
        </div>
        <div>
          <label className={labelClass}>{t('nps', language)}</label>
          <input type="number" value={form.nps} onChange={e => setForm({ ...form, nps: e.target.value })} className={inputClass} placeholder="75" />
        </div>
      </div>

      <div className="flex items-center gap-3">
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={handleSubmit}
          disabled={!validate() || status === 'loading'}
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg font-medium text-sm text-primary-foreground disabled:opacity-50 transition-all"
          style={{ background: 'var(--gradient-primary)' }}
        >
          {status === 'loading' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          {status === 'loading' ? t('loading', language) : t('submit', language)}
        </motion.button>

        {status === 'error' && (
          <motion.button
            initial={{ opacity: 0 }} animate={{ opacity: 1 }}
            onClick={handleSubmit}
            className="flex items-center gap-1 px-3 py-2 rounded-lg text-sm text-anomaly hover:bg-anomaly/10 transition-colors"
          >
            <RefreshCw className="h-3.5 w-3.5" /> {t('retry', language)}
          </motion.button>
        )}
      </div>

      {status === 'success' && response && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mt-4 p-4 rounded-lg border border-success/30 bg-success/5">
          <div className="flex items-center gap-2 mb-2">
            <CheckCircle className="h-4 w-4 text-success" />
            <span className="text-sm font-medium text-success">{t('success', language)}</span>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {Object.entries(response).map(([k, v]) => (
              <div key={k} className="text-xs">
                <span className="text-muted-foreground">{k}: </span>
                <span className="text-foreground font-mono">{v}</span>
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {status === 'error' && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mt-4 p-3 rounded-lg border border-anomaly/30 bg-anomaly/5">
          <div className="flex items-center gap-2">
            <XCircle className="h-4 w-4 text-anomaly" />
            <span className="text-sm text-anomaly">{t('error', language)}: {errorMsg}</span>
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}
