import { motion } from 'framer-motion';
import { Zap } from 'lucide-react';
import { predictiveAlerts } from '@/lib/mockData';
import { useApp } from '@/contexts/AppContext';
import { t } from '@/lib/i18n';

export default function PredictiveAlerts() {
  const { language } = useApp();

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.8 }} className="glass-card p-5">
      <div className="flex items-center gap-2 mb-4">
        <Zap className="h-5 w-5 text-warning" />
        <h2 className="text-lg font-semibold text-foreground">{t('predictiveAlerts', language)}</h2>
      </div>
      <div className="space-y-4">
        {predictiveAlerts.map((alert, i) => {
          const isHigh = alert.probability >= 70;
          const isMed = alert.probability >= 50;
          const barColor = isHigh ? 'bg-anomaly' : isMed ? 'bg-warning' : 'bg-success';

          return (
            <motion.div
              key={alert.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
              className="p-3 rounded-lg border border-border"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-foreground">{alert.metric}</span>
                <span className="text-[10px] text-muted-foreground">{alert.timeframe}</span>
              </div>
              <div className="flex items-center gap-3 mb-2">
                <div className="flex-1 h-2.5 rounded-full bg-muted overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${alert.probability}%` }}
                    transition={{ delay: i * 0.1 + 0.3, duration: 0.8 }}
                    className={`h-full rounded-full ${barColor}`}
                  />
                </div>
                <span className="text-xs font-mono font-bold text-foreground">{alert.probability}%</span>
              </div>
              <div className="flex items-center gap-4 text-[10px] text-muted-foreground font-mono">
                <span>Current: {alert.currentValue}</span>
                <span>Predicted: {alert.predictedValue}</span>
                <span>{t('threshold', language)}: {alert.threshold}</span>
              </div>
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
}
