import { motion } from 'framer-motion';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Area, AreaChart } from 'recharts';
import { trendData } from '@/lib/mockData';
import { useApp } from '@/contexts/AppContext';
import { t } from '@/lib/i18n';

const metrics = [
  { key: 'bedOccupancy', color: '#14b8a6', i18n: 'bedOccupancy' },
  { key: 'opdWaitTime', color: '#f97316', i18n: 'opdWaitTime' },
  { key: 'billingCollection', color: '#8b5cf6', i18n: 'billingCollection' },
  { key: 'nps', color: '#06b6d4', i18n: 'nps' },
];

export default function TrendCharts() {
  const { language } = useApp();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.5 }}
      className="glass-card p-5"
    >
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-foreground">{t('trendCharts', language)}</h2>
        <span className="text-xs text-muted-foreground font-mono">{t('last7Days', language)}</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {metrics.map((m) => (
          <div key={m.key}>
            <p className="text-xs font-medium text-muted-foreground mb-2">{t(m.i18n, language)}</p>
            <ResponsiveContainer width="100%" height={160}>
              <AreaChart data={trendData}>
                <defs>
                  <linearGradient id={`grad-${m.key}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={m.color} stopOpacity={0.3} />
                    <stop offset="95%" stopColor={m.color} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="day" tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    background: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                    fontSize: '12px',
                  }}
                />
                <Area type="monotone" dataKey={m.key} stroke={m.color} strokeWidth={2} fill={`url(#grad-${m.key})`} dot={{ r: 3, fill: m.color }} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        ))}
      </div>
    </motion.div>
  );
}
