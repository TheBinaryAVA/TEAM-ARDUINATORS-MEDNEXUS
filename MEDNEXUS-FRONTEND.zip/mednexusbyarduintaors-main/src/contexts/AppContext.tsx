import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Language } from '@/lib/i18n';

export type UserRole = 'ceo' | 'departmentHead' | 'floorSupervisor';

export interface UserProfile {
  name: string;
  email: string;
  role: UserRole;
  department: string;
  contactInfo: string;
}

interface AppContextType {
  user: UserProfile | null;
  setUser: (u: UserProfile | null) => void;
  theme: 'light' | 'dark';
  setTheme: (t: 'light' | 'dark') => void;
  language: Language;
  setLanguage: (l: Language) => void;
  isLoggedIn: boolean;
  login: (role: UserRole) => void;
  logout: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const defaultUsers: Record<UserRole, UserProfile> = {
  ceo: { name: 'Dr. Arjun Mehta', email: 'arjun.mehta@arduinators.com', role: 'ceo', department: 'Executive', contactInfo: '+91-9876543210' },
  departmentHead: { name: 'Dr. Priya Sharma', email: 'priya.sharma@arduinators.com', role: 'departmentHead', department: 'Cardiology', contactInfo: '+91-9876543211' },
  floorSupervisor: { name: 'Nurse Kavitha R.', email: 'kavitha.r@arduinators.com', role: 'floorSupervisor', department: 'General Ward', contactInfo: '+91-9876543212' },
};

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [theme, setThemeState] = useState<'light' | 'dark'>('dark');
  const [language, setLanguage] = useState<Language>('en');

  const setTheme = (t: 'light' | 'dark') => {
    setThemeState(t);
    document.documentElement.classList.toggle('dark', t === 'dark');
    localStorage.setItem('theme', t);
  };

  useEffect(() => {
    const saved = localStorage.getItem('theme') as 'light' | 'dark' | null;
    const t = saved || 'dark';
    setThemeState(t);
    document.documentElement.classList.toggle('dark', t === 'dark');
  }, []);

  const login = (role: UserRole) => setUser(defaultUsers[role]);
  const logout = () => setUser(null);

  return (
    <AppContext.Provider value={{ user, setUser, theme, setTheme, language, setLanguage, isLoggedIn: !!user, login, logout }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
