export interface KPIData {
  id: string;
  label: string;
  value: number;
  unit: string;
  deviation: number;
  isAnomaly: boolean;
  sparkline: number[];
  target: number;
  i18nKey: string;
}

export interface AlertData {
  id: string;
  message: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH';
  timestamp: string;
  department: string;
  read: boolean;
}

export interface InsightData {
  id: string;
  insight: string;
  confidence: number;
  actions: string[];
  category: string;
}

export interface PredictiveAlert {
  id: string;
  metric: string;
  probability: number;
  threshold: number;
  currentValue: number;
  predictedValue: number;
  timeframe: string;
}

export interface TrendDataPoint {
  day: string;
  bedOccupancy: number;
  opdWaitTime: number;
  billingCollection: number;
  labTAT: number;
  readmissionRate: number;
  nps: number;
}

export const kpiData: KPIData[] = [
  { id: '1', label: 'Bed Occupancy', value: 87.3, unit: '%', deviation: 2.1, isAnomaly: false, sparkline: [82, 84, 85, 87, 86, 88, 87.3], target: 85, i18nKey: 'bedOccupancy' },
  { id: '2', label: 'OPD Wait Time', value: 23, unit: 'min', deviation: -5.2, isAnomaly: true, sparkline: [18, 20, 22, 25, 28, 26, 23], target: 15, i18nKey: 'opdWaitTime' },
  { id: '3', label: 'Billing Collection', value: 94.5, unit: '%', deviation: 1.8, isAnomaly: false, sparkline: [90, 91, 93, 92, 94, 93, 94.5], target: 95, i18nKey: 'billingCollection' },
  { id: '4', label: 'Lab TAT', value: 42, unit: 'min', deviation: -3.1, isAnomaly: false, sparkline: [38, 40, 41, 43, 44, 42, 42], target: 45, i18nKey: 'labTAT' },
  { id: '5', label: 'Readmission Rate', value: 4.2, unit: '%', deviation: 0.8, isAnomaly: true, sparkline: [3.5, 3.8, 4.0, 4.1, 4.5, 4.3, 4.2], target: 3.0, i18nKey: 'readmissionRate' },
  { id: '6', label: 'Net Promoter Score', value: 72, unit: '', deviation: 3.5, isAnomaly: false, sparkline: [65, 67, 68, 70, 71, 73, 72], target: 75, i18nKey: 'nps' },
];

export const alertsData: AlertData[] = [
  { id: '1', message: 'ICU bed occupancy exceeded 95% threshold', severity: 'HIGH', timestamp: '2 min ago', department: 'ICU', read: false },
  { id: '2', message: 'OPD wait time spike detected in Cardiology', severity: 'HIGH', timestamp: '15 min ago', department: 'Cardiology', read: false },
  { id: '3', message: 'Lab TAT improvement noted in Pathology', severity: 'LOW', timestamp: '1 hr ago', department: 'Pathology', read: true },
  { id: '4', message: 'Billing collection dip in Orthopedics', severity: 'MEDIUM', timestamp: '2 hrs ago', department: 'Orthopedics', read: true },
  { id: '5', message: 'Readmission rate trending up in General Ward', severity: 'MEDIUM', timestamp: '3 hrs ago', department: 'General Ward', read: false },
  { id: '6', message: 'NPS improved by 5 points this week', severity: 'LOW', timestamp: '5 hrs ago', department: 'Hospital-wide', read: true },
];

export const insightsData: InsightData[] = [
  { id: '1', insight: 'OPD wait times have increased 23% over the past 3 days. Primary bottleneck identified at patient registration.', confidence: 92, actions: ['Add temporary registration staff during peak hours (9-11 AM)', 'Implement digital pre-registration for returning patients', 'Redistribute queue management across counters'], category: 'Operations' },
  { id: '2', insight: 'Readmission rates in General Ward correlate with discharge timing. Patients discharged after 6 PM show 40% higher readmission.', confidence: 87, actions: ['Shift discharge window to before 4 PM', 'Implement post-discharge follow-up calls within 24 hours', 'Review discharge checklist compliance'], category: 'Clinical' },
  { id: '3', insight: 'Lab TAT has improved 15% following equipment upgrade in Pathology. Similar upgrade in Biochemistry could yield comparable results.', confidence: 78, actions: ['Evaluate ROI for Biochemistry lab equipment upgrade', 'Cross-train pathology staff on new protocols', 'Set up real-time TAT monitoring dashboard'], category: 'Infrastructure' },
  { id: '4', insight: 'NPS scores strongly correlate with nurse response time. Departments with <5 min response time show 20+ higher NPS.', confidence: 85, actions: ['Deploy nurse call optimization system', 'Review staffing ratios in low-NPS departments', 'Implement patient feedback kiosks at discharge'], category: 'Patient Experience' },
];

export const predictiveAlerts: PredictiveAlert[] = [
  { id: '1', metric: 'Bed Occupancy', probability: 78, threshold: 95, currentValue: 87.3, predictedValue: 96.1, timeframe: 'Next 48 hours' },
  { id: '2', metric: 'OPD Wait Time', probability: 65, threshold: 30, currentValue: 23, predictedValue: 32, timeframe: 'Tomorrow Peak Hours' },
  { id: '3', metric: 'Readmission Rate', probability: 55, threshold: 5, currentValue: 4.2, predictedValue: 5.3, timeframe: 'Next 7 days' },
  { id: '4', metric: 'Lab TAT', probability: 40, threshold: 60, currentValue: 42, predictedValue: 48, timeframe: 'Next 3 days' },
];

export const trendData: TrendDataPoint[] = [
  { day: 'Mon', bedOccupancy: 82, opdWaitTime: 18, billingCollection: 90, labTAT: 38, readmissionRate: 3.5, nps: 65 },
  { day: 'Tue', bedOccupancy: 84, opdWaitTime: 20, billingCollection: 91, labTAT: 40, readmissionRate: 3.8, nps: 67 },
  { day: 'Wed', bedOccupancy: 85, opdWaitTime: 22, billingCollection: 93, labTAT: 41, readmissionRate: 4.0, nps: 68 },
  { day: 'Thu', bedOccupancy: 87, opdWaitTime: 25, billingCollection: 92, labTAT: 43, readmissionRate: 4.1, nps: 70 },
  { day: 'Fri', bedOccupancy: 86, opdWaitTime: 28, billingCollection: 94, labTAT: 44, readmissionRate: 4.5, nps: 71 },
  { day: 'Sat', bedOccupancy: 88, opdWaitTime: 26, billingCollection: 93, labTAT: 42, readmissionRate: 4.3, nps: 73 },
  { day: 'Sun', bedOccupancy: 87.3, opdWaitTime: 23, billingCollection: 94.5, labTAT: 42, readmissionRate: 4.2, nps: 72 },
];

export const departments = ['Cardiology', 'Orthopedics', 'Neurology', 'Pediatrics', 'General Ward', 'ICU', 'Emergency', 'Pathology'];
