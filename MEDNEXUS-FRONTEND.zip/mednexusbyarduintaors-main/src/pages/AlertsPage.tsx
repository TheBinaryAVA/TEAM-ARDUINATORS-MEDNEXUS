import AlertsPanel from '@/components/AlertsPanel';

export default function AlertsPage() {
  return (
    <div className="p-4 md:p-6 max-w-[1200px] mx-auto">
      <AlertsPanel />
    </div>
  );
}
