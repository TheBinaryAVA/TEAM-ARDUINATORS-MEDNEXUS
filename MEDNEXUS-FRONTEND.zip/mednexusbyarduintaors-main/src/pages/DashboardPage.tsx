import { motion } from 'framer-motion';
import KPICard from '@/components/KPICard';
import TrendCharts from '@/components/TrendCharts';
import AlertsPanel from '@/components/AlertsPanel';
import InsightsPanel from '@/components/InsightsPanel';
import PredictiveAlerts from '@/components/PredictiveAlerts';
import { kpiData } from '@/lib/mockData';
import { useApp } from '@/contexts/AppContext';
import { t } from '@/lib/i18n';

export default function DashboardPage() {
  const { user, language } = useApp();

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-[1600px] mx-auto">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <h1 className="text-xl md:text-2xl font-bold text-foreground">
          {t('welcome', language)}, {user?.name?.split(' ')[0]} 👋
        </h1>
        <p className="text-sm text-muted-foreground mt-1 capitalize">
          {t(user?.role === 'departmentHead' ? 'departmentHead' : user?.role === 'floorSupervisor' ? 'floorSupervisor' : 'ceo', language)} • {user?.department}
        </p>
      </motion.div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {kpiData.map((kpi, i) => (
          <KPICard key={kpi.id} kpi={kpi} index={i} />
        ))}
      </div>

      <TrendCharts />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <AlertsPanel compact />
        <InsightsPanel compact />
      </div>

      <PredictiveAlerts />
    </div>
  );
}
