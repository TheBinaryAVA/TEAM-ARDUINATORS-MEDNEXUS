import InsightsPanel from '@/components/InsightsPanel';
import PredictiveAlerts from '@/components/PredictiveAlerts';

export default function InsightsPage() {
  return (
    <div className="p-4 md:p-6 space-y-6 max-w-[1200px] mx-auto">
      <InsightsPanel />
      <PredictiveAlerts />
    </div>
  );
}
