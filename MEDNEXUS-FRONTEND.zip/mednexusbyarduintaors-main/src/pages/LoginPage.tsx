import { motion } from 'framer-motion';
import { Shield, HeartPulse } from 'lucide-react';
import { useApp, UserRole } from '@/contexts/AppContext';
import { t } from '@/lib/i18n';

const roles: { key: UserRole; icon: string }[] = [
  { key: 'ceo', icon: '👔' },
  { key: 'departmentHead', icon: '🩺' },
  { key: 'floorSupervisor', icon: '👩‍⚕️' },
];

export default function LoginPage() {
  const { login, language } = useApp();

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: 'var(--gradient-dark)' }}>
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <div className="text-center mb-8">
          <motion.div
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ repeat: Infinity, duration: 3 }}
            className="inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-4"
            style={{ background: 'var(--gradient-primary)' }}
          >
            <HeartPulse className="h-8 w-8 text-primary-foreground" />
          </motion.div>
          <h1 className="text-2xl font-bold gradient-text">{t('hospitalName', language)}</h1>
          <p className="text-sm text-muted-foreground mt-1">{t('commandCenter', language)}</p>
        </div>

        <div className="glass-card p-6 space-y-4">
          <h2 className="text-lg font-semibold text-foreground text-center">{t('login', language)}</h2>
          <p className="text-xs text-muted-foreground text-center">Select a role to enter the demo dashboard</p>

          <div className="space-y-3 pt-2">
            {roles.map((role, i) => (
              <motion.button
                key={role.key}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ scale: 1.02, x: 4 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => login(role.key)}
                className="w-full flex items-center gap-4 p-4 rounded-xl border border-border hover:border-primary/50 hover:bg-accent/50 transition-all group"
              >
                <span className="text-2xl">{role.icon}</span>
                <div className="text-left flex-1">
                  <p className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors">
                    {t(role.key, language)}
                  </p>
                  <p className="text-[10px] text-muted-foreground">
                    {role.key === 'ceo' ? 'Full access to all departments' : role.key === 'departmentHead' ? 'Department-level metrics & alerts' : 'Floor-level operations & monitoring'}
                  </p>
                </div>
                <Shield className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
              </motion.button>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  );
}
