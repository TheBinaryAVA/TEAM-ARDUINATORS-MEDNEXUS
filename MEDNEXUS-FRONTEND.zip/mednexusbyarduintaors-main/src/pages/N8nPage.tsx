import N8nForm from '@/components/N8nForm';

export default function N8nPage() {
  return (
    <div className="p-4 md:p-6 max-w-[900px] mx-auto">
      <N8nForm />
    </div>
  );
}
