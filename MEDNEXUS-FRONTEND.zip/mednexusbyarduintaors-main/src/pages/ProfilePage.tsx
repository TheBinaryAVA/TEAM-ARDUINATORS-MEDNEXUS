import { useState } from 'react';
import { motion } from 'framer-motion';
import { useApp } from '@/contexts/AppContext';
import { t } from '@/lib/i18n';
import { Save, User } from 'lucide-react';
import { toast } from 'sonner';

export default function ProfilePage() {
  const { user, setUser, language } = useApp();
  const [form, setForm] = useState({ ...user! });

  const handleSave = () => {
    setUser(form);
    toast.success(t('success', language));
  };

  const inputClass = "w-full px-3 py-2.5 rounded-lg bg-secondary border border-border text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all";
  const labelClass = "text-xs font-medium text-muted-foreground mb-1.5 block";

  return (
    <div className="p-4 md:p-6 max-w-[700px] mx-auto">
      <motion.h1 initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-xl font-bold text-foreground mb-6">
        {t('editProfile', language)}
      </motion.h1>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-card p-6 space-y-5">
        <div className="flex items-center gap-4 mb-2">
          <div className="w-14 h-14 rounded-xl flex items-center justify-center text-2xl" style={{ background: 'var(--gradient-primary)' }}>
            <User className="h-7 w-7 text-primary-foreground" />
          </div>
          <div>
            <p className="text-lg font-semibold text-foreground">{form.name}</p>
            <p className="text-xs text-muted-foreground capitalize">{t(form.role === 'departmentHead' ? 'departmentHead' : form.role === 'floorSupervisor' ? 'floorSupervisor' : 'ceo', language)}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className={labelClass}>{t('name', language)}</label>
            <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className={inputClass} />
          </div>
          <div>
            <label className={labelClass}>{t('email', language)}</label>
            <input value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} className={inputClass} />
          </div>
          <div>
            <label className={labelClass}>{t('department', language)}</label>
            <input value={form.department} onChange={e => setForm({ ...form, department: e.target.value })} className={inputClass} />
          </div>
          <div>
            <label className={labelClass}>{t('contactInfo', language)}</label>
            <input value={form.contactInfo} onChange={e => setForm({ ...form, contactInfo: e.target.value })} className={inputClass} />
          </div>
        </div>

        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={handleSave}
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg font-medium text-sm text-primary-foreground"
          style={{ background: 'var(--gradient-primary)' }}
        >
          <Save className="h-4 w-4" /> {t('save', language)}
        </motion.button>
      </motion.div>
    </div>
  );
}
