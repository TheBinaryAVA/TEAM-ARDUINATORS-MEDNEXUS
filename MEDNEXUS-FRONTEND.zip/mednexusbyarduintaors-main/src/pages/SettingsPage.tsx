import { useState } from 'react';
import { motion } from 'framer-motion';
import { useApp } from '@/contexts/AppContext';
import { t, Language } from '@/lib/i18n';
import { Sun, Moon } from 'lucide-react';

export default function SettingsPage() {
  const { theme, setTheme, language, setLanguage } = useApp();

  const langs: { value: Language; label: string }[] = [
    { value: 'en', label: 'English' },
    { value: 'hi', label: 'हिन्दी (Hindi)' },
    { value: 'ta', label: 'தமிழ் (Tamil)' },
  ];

  return (
    <div className="p-4 md:p-6 max-w-[700px] mx-auto space-y-6">
      <motion.h1 initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-xl font-bold text-foreground">
        {t('settings', language)}
      </motion.h1>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-card p-5">
        <h2 className="text-sm font-semibold text-foreground mb-4">{t('theme', language)}</h2>
        <div className="flex gap-3">
          {(['light', 'dark'] as const).map(th => (
            <motion.button
              key={th}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setTheme(th)}
              className={`flex items-center gap-2 px-5 py-3 rounded-xl border text-sm font-medium transition-all ${
                theme === th ? 'border-primary bg-accent text-accent-foreground' : 'border-border text-muted-foreground hover:border-primary/30'
              }`}
            >
              {th === 'light' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
              {t(th, language)}
            </motion.button>
          ))}
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="glass-card p-5">
        <h2 className="text-sm font-semibold text-foreground mb-4">{t('language', language)}</h2>
        <div className="flex flex-wrap gap-3">
          {langs.map(l => (
            <motion.button
              key={l.value}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setLanguage(l.value)}
              className={`px-5 py-3 rounded-xl border text-sm font-medium transition-all ${
                language === l.value ? 'border-primary bg-accent text-accent-foreground' : 'border-border text-muted-foreground hover:border-primary/30'
              }`}
            >
              {l.label}
            </motion.button>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
