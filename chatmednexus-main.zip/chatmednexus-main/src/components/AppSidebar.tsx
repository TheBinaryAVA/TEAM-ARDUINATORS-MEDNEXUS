import { motion } from "framer-motion";
import { MessageSquare, ListTodo, BarChart3, Video, Snowflake } from "lucide-react";

export type View = "chat" | "tasks" | "performance" | "video";

const navItems: { view: View; icon: typeof MessageSquare; label: string }[] = [
  { view: "chat", icon: MessageSquare, label: "Chat" },
  { view: "tasks", icon: ListTodo, label: "Tasks" },
  { view: "performance", icon: BarChart3, label: "Dashboard" },
  { view: "video", icon: Video, label: "Video" },
];

const AppSidebar = ({ active, onNavigate }: { active: View; onNavigate: (v: View) => void }) => {
  return (
    <div className="w-16 lg:w-56 h-screen bg-sidebar flex flex-col border-r border-sidebar-border shrink-0">
      {/* Logo */}
      <div className="p-4 flex items-center gap-3 border-b border-sidebar-border">
        <div className="w-8 h-8 rounded-lg ice-gradient flex items-center justify-center">
          <Snowflake className="w-5 h-5 text-primary-foreground" />
        </div>
        <span className="hidden lg:block font-display font-bold text-sidebar-foreground ice-text-gradient">
          IceCare
        </span>
      </div>

      {/* Nav */}
      <nav className="flex-1 p-2 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = active === item.view;
          return (
            <button
              key={item.view}
              onClick={() => onNavigate(item.view)}
              className="relative w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors"
            >
              {isActive && (
                <motion.div
                  layoutId="sidebar-active"
                  className="absolute inset-0 bg-sidebar-accent border border-sidebar-primary/20 rounded-lg"
                  transition={{ type: "spring", bounce: 0.15, duration: 0.4 }}
                />
              )}
              <Icon className={`relative z-10 w-5 h-5 ${isActive ? "text-sidebar-primary" : "text-sidebar-foreground/60"}`} />
              <span className={`relative z-10 hidden lg:block font-medium ${isActive ? "text-sidebar-primary" : "text-sidebar-foreground/60"}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-xs font-display font-bold text-primary">
            A
          </div>
          <div className="hidden lg:block">
            <p className="text-xs font-medium text-sidebar-foreground">Admin</p>
            <p className="text-[10px] text-sidebar-foreground/50">Hospital Ops</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AppSidebar;
