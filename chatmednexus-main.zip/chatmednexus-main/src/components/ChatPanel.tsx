import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Send } from "lucide-react";
import IceAvatar from "./IceAvatar";
import type { Language } from "./LanguageToggle";

type Message = { id: number; role: "user" | "assistant"; text: string };

const greetings: Record<Language, string> = {
  en: "Hello! I'm your Ice Assistant. I can help you manage tasks, check employee performance, schedule video consultations, and more. How can I help you today?",
  hi: "नमस्ते! मैं आपका आइस असिस्टेंट हूँ। मैं कार्य प्रबंधन, कर्मचारी प्रदर्शन, वीडियो परामर्श और बहुत कुछ में मदद कर सकता हूँ। आज मैं आपकी कैसे मदद कर सकता हूँ?",
  ta: "வணக்கம்! நான் உங்கள் ஐஸ் உதவியாளர். பணி மேலாண்மை, பணியாளர் செயல்திறன், வீடியோ ஆலோசனை மற்றும் பலவற்றில் உதவ முடியும். இன்று நான் உங்களுக்கு எப்படி உதவ முடியும்?",
};

const responses: Record<Language, string[]> = {
  en: [
    "I've checked the ICU dashboard — there are 3 pending tasks for today. Shall I assign them?",
    "Employee performance for this week shows a 12% improvement in response times. Great progress!",
    "OPD wait time is currently 18 minutes. I can notify the front desk to expedite.",
    "I've scheduled a video consultation with the Radiology department for 3:00 PM today.",
    "Billing collections show 5 overdue items. I recommend a follow-up with the finance team.",
  ],
  hi: [
    "मैंने ICU डैशबोर्ड चेक किया — आज 3 लंबित कार्य हैं। क्या मैं उन्हें असाइन करूँ?",
    "इस सप्ताह कर्मचारी प्रदर्शन में प्रतिक्रिया समय में 12% सुधार दिखाता है।",
    "OPD प्रतीक्षा समय वर्तमान में 18 मिनट है। मैं फ्रंट डेस्क को सूचित कर सकता हूँ।",
    "मैंने आज दोपहर 3:00 बजे रेडियोलॉजी विभाग के साथ वीडियो परामर्श निर्धारित किया है।",
    "बिलिंग संग्रह में 5 अतिदेय आइटम हैं। वित्त टीम से संपर्क करें।",
  ],
  ta: [
    "ICU டாஷ்போர்டை சரிபார்த்தேன் — இன்று 3 நிலுவையிலுள்ள பணிகள் உள்ளன. ஒதுக்கவா?",
    "இந்த வாரம் பணியாளர் செயல்திறன் மறுமொழி நேரத்தில் 12% முன்னேற்றம் காட்டுகிறது.",
    "OPD காத்திருப்பு நேரம் தற்போது 18 நிமிடங்கள். முன்னால் அறிவிக்க முடியும்.",
    "இன்று மதியம் 3:00 மணிக்கு கதிரியக்கவியல் துறையுடன் வீடியோ ஆலோசனை திட்டமிட்டேன்.",
    "பில்லிங் வசூலில் 5 தாமதமான பொருட்கள் உள்ளன. நிதிக் குழுவுடன் தொடர்பு கொள்ளுங்கள்.",
  ],
};

const ChatPanel = ({ language }: { language: Language }) => {
  const [messages, setMessages] = useState<Message[]>([
    { id: 0, role: "assistant", text: greetings[language] },
  ]);
  const [input, setInput] = useState("");
  const [isSpeaking, setIsSpeaking] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const idCounter = useRef(1);

  useEffect(() => {
    setMessages([{ id: 0, role: "assistant", text: greetings[language] }]);
  }, [language]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = () => {
    if (!input.trim()) return;
    const userMsg: Message = { id: idCounter.current++, role: "user", text: input };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsSpeaking(true);

    setTimeout(() => {
      const pool = responses[language];
      const reply = pool[Math.floor(Math.random() * pool.length)];
      setMessages((prev) => [...prev, { id: idCounter.current++, role: "assistant", text: reply }]);
      setIsSpeaking(false);
    }, 1200);
  };

  return (
    <div className="flex flex-col h-full">
      {/* Avatar header */}
      <div className="flex items-center gap-4 p-4 border-b border-border/50">
        <IceAvatar speaking={isSpeaking} />
        <div>
          <h2 className="text-lg font-display font-semibold ice-text-gradient">Ice Assistant</h2>
          <p className="text-xs text-muted-foreground">
            {language === "en" ? "Online • Ready to help" : language === "hi" ? "ऑनलाइन • मदद के लिए तैयार" : "ஆன்லைன் • உதவ தயார்"}
          </p>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        <AnimatePresence>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[80%] px-4 py-2.5 rounded-2xl text-sm leading-relaxed ${
                  msg.role === "user"
                    ? "bg-primary/20 border border-primary/30 text-foreground"
                    : "glass-card text-foreground"
                }`}
              >
                {msg.text}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="p-4 border-t border-border/50">
        <div className="flex items-center gap-2 glass-card p-2">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
            placeholder={
              language === "en" ? "Type a message..." : language === "hi" ? "संदेश लिखें..." : "செய்தி எழுதுங்கள்..."
            }
            className="flex-1 bg-transparent border-none outline-none text-sm text-foreground placeholder:text-muted-foreground px-2"
          />
          <button
            onClick={handleSend}
            className="p-2 rounded-lg bg-primary/20 hover:bg-primary/30 text-primary transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatPanel;
