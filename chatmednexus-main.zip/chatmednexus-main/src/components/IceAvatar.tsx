import { motion } from "framer-motion";

const IceAvatar = ({ speaking = false }: { speaking?: boolean }) => {
  return (
    <div className="relative flex items-center justify-center">
      {/* Outer glow rings */}
      <motion.div
        className="absolute w-28 h-28 rounded-full border border-primary/20"
        animate={{ scale: speaking ? [1, 1.15, 1] : 1, opacity: speaking ? [0.3, 0.6, 0.3] : 0.2 }}
        transition={{ duration: 2, repeat: Infinity }}
      />
      <motion.div
        className="absolute w-24 h-24 rounded-full border border-ice-crystal/30"
        animate={{ scale: speaking ? [1, 1.1, 1] : 1, opacity: speaking ? [0.4, 0.7, 0.4] : 0.3 }}
        transition={{ duration: 1.5, repeat: Infinity, delay: 0.3 }}
      />

      {/* Main avatar body */}
      <motion.div
        className="relative w-20 h-20 rounded-full ice-gradient animate-pulse-glow"
        animate={{ y: speaking ? [0, -4, 0] : [0, -6, 0] }}
        transition={{ duration: speaking ? 0.8 : 4, repeat: Infinity, ease: "easeInOut" }}
      >
        {/* Face */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="flex flex-col items-center gap-2">
            {/* Eyes */}
            <div className="flex gap-3">
              <motion.div
                className="w-2.5 h-2.5 rounded-full bg-primary-foreground"
                animate={speaking ? { scaleY: [1, 0.3, 1] } : {}}
                transition={{ duration: 0.4, repeat: Infinity, repeatDelay: 2 }}
              />
              <motion.div
                className="w-2.5 h-2.5 rounded-full bg-primary-foreground"
                animate={speaking ? { scaleY: [1, 0.3, 1] } : {}}
                transition={{ duration: 0.4, repeat: Infinity, repeatDelay: 2, delay: 0.1 }}
              />
            </div>
            {/* Mouth */}
            <motion.div
              className="w-4 h-1.5 rounded-full bg-primary-foreground/80"
              animate={speaking ? { scaleX: [1, 1.4, 0.8, 1], scaleY: [1, 1.5, 0.7, 1] } : {}}
              transition={{ duration: 0.3, repeat: Infinity }}
            />
          </div>
        </div>

        {/* Crystal shards */}
        <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-3 h-5 bg-ice-frost/40 rotate-12 rounded-sm" />
        <div className="absolute -top-1 left-3 w-2 h-4 bg-ice-crystal/30 -rotate-12 rounded-sm" />
        <div className="absolute -top-1 right-3 w-2 h-3 bg-ice-frost/30 rotate-6 rounded-sm" />
      </motion.div>
    </div>
  );
};

export default IceAvatar;
