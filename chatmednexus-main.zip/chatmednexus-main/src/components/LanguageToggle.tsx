import { motion } from "framer-motion";

const languages = [
  { code: "en", label: "EN", name: "English" },
  { code: "hi", label: "हिं", name: "हिन्दी" },
  { code: "ta", label: "த", name: "தமிழ்" },
] as const;

export type Language = (typeof languages)[number]["code"];

const LanguageToggle = ({
  current,
  onChange,
}: {
  current: Language;
  onChange: (lang: Language) => void;
}) => {
  return (
    <div className="flex items-center gap-1 glass-card p-1">
      {languages.map((lang) => (
        <button
          key={lang.code}
          onClick={() => onChange(lang.code)}
          className="relative px-3 py-1.5 text-sm font-display rounded-lg transition-colors"
        >
          {current === lang.code && (
            <motion.div
              layoutId="lang-active"
              className="absolute inset-0 bg-primary/20 border border-primary/30 rounded-lg"
              transition={{ type: "spring", bounce: 0.2, duration: 0.4 }}
            />
          )}
          <span className={`relative z-10 ${current === lang.code ? "text-primary" : "text-muted-foreground"}`}>
            {lang.label}
          </span>
        </button>
      ))}
    </div>
  );
};

export default LanguageToggle;
