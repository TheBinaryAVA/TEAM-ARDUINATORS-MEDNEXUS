import { motion } from "framer-motion";
import { TrendingUp, TrendingDown, Users, Clock, Star, Activity } from "lucide-react";
import type { Language } from "./LanguageToggle";

const labels: Record<Language, { title: string; effectiveness: string; efficiency: string; responsiveness: string; overall: string; topPerformers: string; needsAttention: string }> = {
  en: { title: "Employee Performance", effectiveness: "Effectiveness", efficiency: "Efficiency", responsiveness: "Responsiveness", overall: "Overall Score", topPerformers: "Top Performers", needsAttention: "Needs Attention" },
  hi: { title: "कर्मचारी प्रदर्शन", effectiveness: "प्रभावशीलता", efficiency: "दक्षता", responsiveness: "प्रतिक्रिया", overall: "कुल स्कोर", topPerformers: "शीर्ष प्रदर्शक", needsAttention: "ध्यान आवश्यक" },
  ta: { title: "பணியாளர் செயல்திறன்", effectiveness: "திறன்", efficiency: "செயல்திறன்", responsiveness: "பதிலளிப்பு", overall: "மொத்த மதிப்பெண்", topPerformers: "சிறந்த செயல்திறன்", needsAttention: "கவனம் தேவை" },
};

const metrics = [
  { key: "effectiveness", value: 87, change: +5, icon: Star },
  { key: "efficiency", value: 92, change: +3, icon: Activity },
  { key: "responsiveness", value: 78, change: -2, icon: Clock },
];

const employees = [
  { name: "Dr. Priya Sharma", dept: "ICU", score: 96, trend: "up" as const },
  { name: "Ravi Kumar", dept: "OPD", score: 94, trend: "up" as const },
  { name: "Anitha Devi", dept: "Pathology", score: 91, trend: "up" as const },
  { name: "Suresh M.", dept: "Billing", score: 62, trend: "down" as const },
  { name: "Lakshmi P.", dept: "Ward B", score: 58, trend: "down" as const },
];

const PerformanceDashboard = ({ language }: { language: Language }) => {
  const l = labels[language];

  return (
    <div className="p-6 space-y-6">
      <h2 className="text-2xl font-display font-bold ice-text-gradient">{l.title}</h2>

      {/* Metric cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {metrics.map((m, i) => {
          const Icon = m.icon;
          const labelKey = m.key as keyof typeof l;
          return (
            <motion.div
              key={m.key}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="glass-card p-5 space-y-3"
            >
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground font-medium">{l[labelKey]}</span>
                <Icon className="w-4 h-4 text-primary" />
              </div>
              <div className="flex items-end gap-3">
                <span className="text-3xl font-display font-bold text-foreground">{m.value}%</span>
                <span className={`flex items-center gap-1 text-xs font-medium ${m.change > 0 ? "text-ice-success" : "text-destructive"}`}>
                  {m.change > 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                  {m.change > 0 ? "+" : ""}{m.change}%
                </span>
              </div>
              {/* Progress bar */}
              <div className="h-1.5 rounded-full bg-secondary overflow-hidden">
                <motion.div
                  className="h-full rounded-full bg-primary"
                  initial={{ width: 0 }}
                  animate={{ width: `${m.value}%` }}
                  transition={{ duration: 1, delay: i * 0.1 + 0.3 }}
                />
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Overall */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="glass-card p-6 flex items-center gap-6"
      >
        <div className="relative w-20 h-20">
          <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
            <circle cx="50" cy="50" r="42" fill="none" stroke="hsl(var(--secondary))" strokeWidth="8" />
            <motion.circle
              cx="50" cy="50" r="42" fill="none" stroke="hsl(var(--primary))" strokeWidth="8"
              strokeLinecap="round" strokeDasharray={264}
              initial={{ strokeDashoffset: 264 }}
              animate={{ strokeDashoffset: 264 - (264 * 86) / 100 }}
              transition={{ duration: 1.5 }}
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-lg font-display font-bold text-foreground">86%</span>
          </div>
        </div>
        <div>
          <h3 className="font-display font-semibold text-foreground text-lg">{l.overall}</h3>
          <p className="text-sm text-muted-foreground flex items-center gap-1">
            <TrendingUp className="w-3 h-3 text-ice-success" /> +2.1% vs last week
          </p>
        </div>
      </motion.div>

      {/* Employee list */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-3">
          <h3 className="text-sm font-display font-medium text-muted-foreground uppercase tracking-wider flex items-center gap-2">
            <Star className="w-4 h-4 text-ice-success" /> {l.topPerformers}
          </h3>
          {employees.filter(e => e.trend === "up").map((emp, i) => (
            <motion.div
              key={emp.name}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.08 }}
              className="glass-card p-3 flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-xs font-display font-bold text-primary">
                  {emp.name.charAt(0)}
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">{emp.name}</p>
                  <p className="text-xs text-muted-foreground">{emp.dept}</p>
                </div>
              </div>
              <span className="text-sm font-display font-bold text-ice-success">{emp.score}</span>
            </motion.div>
          ))}
        </div>
        <div className="space-y-3">
          <h3 className="text-sm font-display font-medium text-muted-foreground uppercase tracking-wider flex items-center gap-2">
            <Users className="w-4 h-4 text-ice-warning" /> {l.needsAttention}
          </h3>
          {employees.filter(e => e.trend === "down").map((emp, i) => (
            <motion.div
              key={emp.name}
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.08 }}
              className="glass-card p-3 flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-ice-warning/20 flex items-center justify-center text-xs font-display font-bold text-ice-warning">
                  {emp.name.charAt(0)}
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">{emp.name}</p>
                  <p className="text-xs text-muted-foreground">{emp.dept}</p>
                </div>
              </div>
              <span className="text-sm font-display font-bold text-destructive">{emp.score}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default PerformanceDashboard;
