import { useState } from "react";
import { motion } from "framer-motion";
import { Plus, CheckCircle2, Clock, AlertTriangle, Calendar } from "lucide-react";
import type { Language } from "./LanguageToggle";

type Task = {
  id: number;
  title: string;
  department: string;
  priority: "high" | "medium" | "low";
  status: "pending" | "in-progress" | "completed";
  due: string;
};

const labels: Record<Language, { title: string; add: string; pending: string; inProgress: string; completed: string }> = {
  en: { title: "Task Management", add: "Add Task", pending: "Pending", inProgress: "In Progress", completed: "Completed" },
  hi: { title: "कार्य प्रबंधन", add: "कार्य जोड़ें", pending: "लंबित", inProgress: "प्रगति में", completed: "पूर्ण" },
  ta: { title: "பணி மேலாண்மை", add: "பணி சேர்", pending: "நிலுவை", inProgress: "முன்னேற்றம்", completed: "நிறைவு" },
};

const initialTasks: Task[] = [
  { id: 1, title: "ICU Patient Rounds", department: "ICU", priority: "high", status: "pending", due: "Today 10:00 AM" },
  { id: 2, title: "Lab Report Review", department: "Pathology", priority: "medium", status: "in-progress", due: "Today 12:00 PM" },
  { id: 3, title: "Staff Meeting - Ward B", department: "Admin", priority: "low", status: "completed", due: "Today 09:00 AM" },
  { id: 4, title: "Billing Follow-up", department: "Finance", priority: "high", status: "pending", due: "Today 02:00 PM" },
  { id: 5, title: "Equipment Maintenance", department: "Facilities", priority: "medium", status: "pending", due: "Today 04:00 PM" },
  { id: 6, title: "Discharge Summary - Rm 204", department: "OPD", priority: "high", status: "in-progress", due: "Today 11:30 AM" },
];

const priorityColors: Record<string, string> = {
  high: "border-destructive/50 bg-destructive/10 text-destructive",
  medium: "border-ice-warning/50 bg-ice-warning/10 text-ice-warning",
  low: "border-ice-success/50 bg-ice-success/10 text-ice-success",
};

const statusIcons: Record<string, React.ReactNode> = {
  pending: <Clock className="w-4 h-4 text-muted-foreground" />,
  "in-progress": <AlertTriangle className="w-4 h-4 text-ice-warning" />,
  completed: <CheckCircle2 className="w-4 h-4 text-ice-success" />,
};

const TaskManager = ({ language }: { language: Language }) => {
  const [tasks, setTasks] = useState(initialTasks);
  const l = labels[language];

  const toggleStatus = (id: number) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id !== id) return t;
        const next = t.status === "pending" ? "in-progress" : t.status === "in-progress" ? "completed" : "pending";
        return { ...t, status: next };
      })
    );
  };

  const grouped = {
    pending: tasks.filter((t) => t.status === "pending"),
    "in-progress": tasks.filter((t) => t.status === "in-progress"),
    completed: tasks.filter((t) => t.status === "completed"),
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-display font-bold ice-text-gradient">{l.title}</h2>
        <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary/20 hover:bg-primary/30 text-primary text-sm font-medium transition-colors frost-border">
          <Plus className="w-4 h-4" /> {l.add}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {(["pending", "in-progress", "completed"] as const).map((status) => (
          <div key={status} className="space-y-3">
            <div className="flex items-center gap-2 text-sm font-display font-medium text-muted-foreground uppercase tracking-wider">
              {statusIcons[status]}
              {status === "pending" ? l.pending : status === "in-progress" ? l.inProgress : l.completed}
              <span className="ml-auto text-xs bg-secondary px-2 py-0.5 rounded-full">
                {grouped[status].length}
              </span>
            </div>
            {grouped[status].map((task, i) => (
              <motion.div
                key={task.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                onClick={() => toggleStatus(task.id)}
                className="glass-card-hover p-4 cursor-pointer space-y-2"
              >
                <div className="flex items-start justify-between gap-2">
                  <span className="text-sm font-medium text-foreground">{task.title}</span>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full border font-medium ${priorityColors[task.priority]}`}>
                    {task.priority}
                  </span>
                </div>
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <span>{task.department}</span>
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" /> {task.due}
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};

export default TaskManager;
