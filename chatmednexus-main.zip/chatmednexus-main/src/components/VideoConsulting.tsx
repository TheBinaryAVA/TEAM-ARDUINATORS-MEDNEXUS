import { motion } from "framer-motion";
import { Video, Phone, Calendar, Clock, Users, MessageSquare } from "lucide-react";
import type { Language } from "./LanguageToggle";

const labels: Record<Language, { title: string; upcoming: string; join: string; schedule: string; past: string; summary: string }> = {
  en: { title: "Video Consulting", upcoming: "Upcoming Consultations", join: "Join", schedule: "Schedule Call", past: "Past Consultations", summary: "AI Summary" },
  hi: { title: "वीडियो परामर्श", upcoming: "आगामी परामर्श", join: "शामिल हों", schedule: "कॉल शेड्यूल करें", past: "पिछले परामर्श", summary: "AI सारांश" },
  ta: { title: "வீடியோ ஆலோசனை", upcoming: "வரவிருக்கும் ஆலோசனைகள்", join: "சேர", schedule: "அழைப்பு திட்டமிடு", past: "முந்தைய ஆலோசனைகள்", summary: "AI சுருக்கம்" },
};

const upcomingCalls = [
  { id: 1, title: "ICU-Cardiology Sync", time: "3:00 PM", participants: ["Dr. Priya", "Dr. Rajan", "Nurse Anitha"], department: "ICU ↔ Cardiology", status: "starting-soon" },
  { id: 2, title: "Weekly Admin Review", time: "4:30 PM", participants: ["Admin Team", "HR Lead"], department: "Administration", status: "scheduled" },
  { id: 3, title: "Lab Results Discussion", time: "Tomorrow 10:00 AM", participants: ["Dr. Kumar", "Lab Head"], department: "Pathology ↔ OPD", status: "scheduled" },
];

const pastCalls = [
  { id: 4, title: "Emergency Protocol Review", date: "Yesterday", duration: "32 min", summary: "Discussed new triage protocols. Action: Update SOP by Friday. Assign Dr. Sharma to draft." },
  { id: 5, title: "Billing Dispute Resolution", date: "2 days ago", duration: "18 min", summary: "Resolved 3 pending disputes. Action: Follow up with insurance providers. Deadline: This week." },
];

const VideoConsulting = ({ language }: { language: Language }) => {
  const l = labels[language];

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-display font-bold ice-text-gradient">{l.title}</h2>
        <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary/20 hover:bg-primary/30 text-primary text-sm font-medium transition-colors frost-border">
          <Video className="w-4 h-4" /> {l.schedule}
        </button>
      </div>

      {/* Upcoming */}
      <div className="space-y-3">
        <h3 className="text-sm font-display font-medium text-muted-foreground uppercase tracking-wider flex items-center gap-2">
          <Calendar className="w-4 h-4" /> {l.upcoming}
        </h3>
        {upcomingCalls.map((call, i) => (
          <motion.div
            key={call.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 }}
            className={`glass-card p-4 flex items-center justify-between ${call.status === "starting-soon" ? "border-primary/40" : ""}`}
          >
            <div className="space-y-1.5">
              <div className="flex items-center gap-2">
                <h4 className="text-sm font-medium text-foreground">{call.title}</h4>
                {call.status === "starting-soon" && (
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-primary/20 text-primary border border-primary/30 animate-pulse">
                    Starting Soon
                  </span>
                )}
              </div>
              <div className="flex items-center gap-4 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {call.time}</span>
                <span className="flex items-center gap-1"><Users className="w-3 h-3" /> {call.participants.length} participants</span>
                <span>{call.department}</span>
              </div>
            </div>
            <button className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              call.status === "starting-soon"
                ? "bg-primary text-primary-foreground hover:bg-primary/90 ice-glow"
                : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
            }`}>
              {call.status === "starting-soon" ? <Phone className="w-4 h-4" /> : <Calendar className="w-4 h-4" />}
              {call.status === "starting-soon" ? l.join : l.schedule}
            </button>
          </motion.div>
        ))}
      </div>

      {/* Past */}
      <div className="space-y-3">
        <h3 className="text-sm font-display font-medium text-muted-foreground uppercase tracking-wider flex items-center gap-2">
          <MessageSquare className="w-4 h-4" /> {l.past}
        </h3>
        {pastCalls.map((call, i) => (
          <motion.div
            key={call.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 }}
            className="glass-card p-4 space-y-2"
          >
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-medium text-foreground">{call.title}</h4>
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                <span>{call.date}</span>
                <span>{call.duration}</span>
              </div>
            </div>
            <div className="bg-secondary/50 rounded-lg p-3 text-xs text-secondary-foreground">
              <span className="text-primary font-medium">{l.summary}:</span> {call.summary}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default VideoConsulting;
