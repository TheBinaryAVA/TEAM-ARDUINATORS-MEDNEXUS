import { useState } from "react";
import AppSidebar, { type View } from "@/components/AppSidebar";
import ChatPanel from "@/components/ChatPanel";
import TaskManager from "@/components/TaskManager";
import PerformanceDashboard from "@/components/PerformanceDashboard";
import VideoConsulting from "@/components/VideoConsulting";
import LanguageToggle, { type Language } from "@/components/LanguageToggle";

const Index = () => {
  const [view, setView] = useState<View>("chat");
  const [language, setLanguage] = useState<Language>("en");

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <AppSidebar active={view} onNavigate={setView} />
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <div className="flex items-center justify-between px-6 py-3 border-b border-border/50">
          <h1 className="text-lg font-display font-semibold text-foreground">
            {view === "chat" ? "Ice Assistant" : view === "tasks" ? "Task Management" : view === "performance" ? "Performance" : "Video Consulting"}
          </h1>
          <LanguageToggle current={language} onChange={setLanguage} />
        </div>
        {/* Content */}
        <div className="flex-1 overflow-y-auto">
          {view === "chat" && <ChatPanel language={language} />}
          {view === "tasks" && <TaskManager language={language} />}
          {view === "performance" && <PerformanceDashboard language={language} />}
          {view === "video" && <VideoConsulting language={language} />}
        </div>
      </div>
    </div>
  );
};

export default Index;
