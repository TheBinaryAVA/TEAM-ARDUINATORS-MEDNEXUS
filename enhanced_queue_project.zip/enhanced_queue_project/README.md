# Enhanced Queue Management System

Detects and counts people in a defined queue region using YOLOv8,
logs results to CSV, saves an annotated output video, and triggers
alerts when the queue exceeds a configurable threshold.

## Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Run
```bash
python main.py
```

### 3. Optional flags
```bash
# Show live video window while processing
python main.py --display

# Use a custom config file
python main.py --config my_config.json
```

### 4. View outputs
| File | Description |
|------|-------------|
| `outputs/processed_output.mp4` | Annotated video with bounding boxes & HUD |
| `outputs/queue_log.csv`        | Per-frame CSV log (timestamp, count, alert) |

---

## Configuration (`config.json`)

| Key | Description |
|-----|-------------|
| `input_video`   | Path to input video |
| `output_video`  | Path for annotated output video |
| `csv_log_path`  | Path for CSV log file |
| `queue_region`  | `[x1, y1, x2, y2]` pixel rectangle |
| `display`       | `true`/`false` — show live feed |
| `threshold`     | Alert fires when count ≥ this value |
| `model`         | YOLO model weights (`yolov8n.pt` auto-downloads) |
| `confidence`    | Detection confidence threshold (0–1) |
| `frame_skip`    | Process every N-th frame (speeds up processing) |

---

## Project Structure

```
enhanced_queue_project/
├── main.py          # Entry point
├── queue_utils.py   # Drawing & counting helpers
├── alerts.py        # Alert logic
├── config.json      # Configuration
├── requirements.txt # Python dependencies
├── videos/
│   └── demo_input.mp4   # Demo video (synthetic people walking into queue)
└── outputs/             # Generated files appear here
```

## Notes
- YOLOv8 model weights download automatically on first run (~6 MB for `yolov8n.pt`).
- Requires Python 3.8+.
- On headless servers, set `"display": false` in config.json.
