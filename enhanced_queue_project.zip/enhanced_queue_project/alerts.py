"""
alerts.py - Alert system for queue threshold breaches.
"""

import time
from datetime import datetime


# Minimum seconds between repeated console alerts (avoids spam).
_ALERT_COOLDOWN = 5.0
_last_alert_time: float = 0.0


def check_and_trigger_alert(count: int, threshold: int, frame_idx: int) -> bool:
    """
    Evaluate the current queue count against the threshold and trigger an
    alert when the threshold is exceeded.

    Alert output is printed to the console and rate-limited by _ALERT_COOLDOWN
    to prevent flooding during long threshold-breach sequences.

    Args:
        count:     Number of people currently in the queue region.
        threshold: Maximum allowed number before an alert fires.
        frame_idx: Current video frame number (used for log messages).

    Returns:
        True  – threshold exceeded (alert state active).
        False – count is within acceptable limits.
    """
    global _last_alert_time

    if count < threshold:
        return False

    now = time.time()
    if now - _last_alert_time >= _ALERT_COOLDOWN:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(
            f"[ALERT] {timestamp} | Frame {frame_idx:>6} | "
            f"Queue size {count} exceeds threshold of {threshold}!"
        )
        _last_alert_time = now

    return True


def format_alert_overlay(count: int, threshold: int) -> str:
    """
    Return a short string suitable for overlaying on the video frame.

    Args:
        count:     Current queue count.
        threshold: Alert threshold.

    Returns:
        A formatted alert string, or an empty string if no alert.
    """
    if count >= threshold:
        return f"ALERT: {count}/{threshold} people in queue!"
    return ""
