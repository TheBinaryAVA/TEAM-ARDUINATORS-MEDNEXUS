"""
main.py - Queue Management System using Ultralytics YOLO.

Usage:
    python main.py
    python main.py --config config.json
    python main.py --display          # override display flag to True

The script:
  1. Reads configuration from config.json.
  2. Opens the input video with OpenCV.
  3. Runs YOLOv8 person detection on each frame.
  4. Counts people whose centroid falls inside the defined queue region.
  5. Draws the region, bounding boxes, and HUD on every frame.
  6. Triggers console alerts when the count exceeds the threshold.
  7. Writes per-frame statistics to a CSV log.
  8. Saves the annotated video to the output path.
"""

import argparse
import csv
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np

# ── Graceful import for Ultralytics ────────────────────────────────────────────
try:
    from ultralytics import YOLO
except ImportError:
    print("[ERROR] Ultralytics not found. Install it with:  pip install ultralytics")
    sys.exit(1)

from alerts import check_and_trigger_alert, format_alert_overlay
from queue_utils import (
    count_people_in_region,
    draw_detections,
    draw_hud,
    draw_queue_region,
)


# ── Helpers ────────────────────────────────────────────────────────────────────

def load_config(path: str) -> dict:
    """Load and validate the JSON configuration file."""
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Config file not found: {path}")
    with open(path, "r") as fh:
        cfg = json.load(fh)

    required = ["input_video", "output_video", "csv_log_path",
                 "queue_region", "threshold", "model"]
    for key in required:
        if key not in cfg:
            raise KeyError(f"Missing required config key: '{key}'")

    return cfg


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Queue Management System")
    p.add_argument("--config", default="config.json", help="Path to config JSON")
    p.add_argument("--display", action="store_true",
                   help="Force display of video feed (overrides config)")
    return p.parse_args()


def ensure_dirs(paths: list[str]) -> None:
    for p in paths:
        Path(p).parent.mkdir(parents=True, exist_ok=True)


def open_video(path: str) -> cv2.VideoCapture:
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise IOError(f"Cannot open video: {path}")
    return cap


def get_video_writer(path: str, cap: cv2.VideoCapture) -> cv2.VideoWriter:
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    fps    = cap.get(cv2.CAP_PROP_FPS) or 25.0
    width  = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    return cv2.VideoWriter(path, fourcc, fps, (width, height))


def draw_alert_banner(frame: np.ndarray, message: str) -> np.ndarray:
    """Draw a red alert banner across the bottom of the frame."""
    if not message:
        return frame
    h, w = frame.shape[:2]
    cv2.rectangle(frame, (0, h - 40), (w, h), (0, 0, 180), -1)
    cv2.putText(frame, message, (10, h - 12),
                cv2.FONT_HERSHEY_SIMPLEX, 0.75, (255, 255, 255), 2, cv2.LINE_AA)
    return frame


# ── Main ───────────────────────────────────────────────────────────────────────

def main() -> None:
    args = parse_args()
    cfg  = load_config(args.config)

    # ── Resolve paths ──────────────────────────────────────────────────────────
    input_video  = cfg["input_video"]
    output_video = cfg["output_video"]
    csv_path     = cfg["csv_log_path"]
    region       = cfg["queue_region"]   # [x1, y1, x2, y2]
    threshold    = int(cfg["threshold"])
    display      = args.display or cfg.get("display", False)
    model_name   = cfg.get("model", "yolov8n.pt")
    confidence   = float(cfg.get("confidence", 0.4))
    frame_skip   = int(cfg.get("frame_skip", 1))  # process every N-th frame

    ensure_dirs([output_video, csv_path])

    print(f"[INFO] Loading YOLO model: {model_name}")
    model = YOLO(model_name)

    print(f"[INFO] Opening video: {input_video}")
    cap    = open_video(input_video)
    writer = get_video_writer(output_video, cap)

    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    video_fps    = cap.get(cv2.CAP_PROP_FPS) or 25.0

    print(f"[INFO] Video: {total_frames} frames @ {video_fps:.1f} FPS")
    print(f"[INFO] Queue region : {region}")
    print(f"[INFO] Alert threshold: {threshold} people")
    print(f"[INFO] Output video : {output_video}")
    print(f"[INFO] CSV log      : {csv_path}")
    print("-" * 60)

    # ── CSV setup ──────────────────────────────────────────────────────────────
    csv_file   = open(csv_path, "w", newline="")
    csv_writer = csv.writer(csv_file)
    csv_writer.writerow(["timestamp", "frame", "people_in_queue",
                         "total_detections", "alert"])

    # ── Processing loop ────────────────────────────────────────────────────────
    frame_idx       = 0
    last_count      = 0
    processed_count = 0
    t_start         = time.time()

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        frame_idx += 1

        # Skip frames to speed things up (reuse last count for skipped frames)
        if frame_idx % frame_skip != 0:
            writer.write(frame)
            continue

        # ── YOLO inference (person class = 0) ──────────────────────────────────
        results = model(frame, classes=[0], conf=confidence, verbose=False)

        detections = []
        for r in results:
            for box in r.boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
                conf_val = float(box.conf[0])
                detections.append((x1, y1, x2, y2, conf_val))

        queue_count = count_people_in_region(detections, region)
        last_count  = queue_count
        alert_active = check_and_trigger_alert(queue_count, threshold, frame_idx)

        # ── Annotation ─────────────────────────────────────────────────────────
        frame = draw_detections(frame, detections, region)
        frame = draw_queue_region(frame, region, queue_count, threshold)

        elapsed  = time.time() - t_start
        proc_fps = processed_count / elapsed if elapsed > 0 else 0.0
        frame    = draw_hud(frame, frame_idx, proc_fps, queue_count, alert_active)

        alert_msg = format_alert_overlay(queue_count, threshold)
        frame     = draw_alert_banner(frame, alert_msg)

        writer.write(frame)
        processed_count += 1

        # ── CSV log ────────────────────────────────────────────────────────────
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        csv_writer.writerow([timestamp, frame_idx, queue_count,
                              len(detections), int(alert_active)])

        # ── Optional display ───────────────────────────────────────────────────
        if display:
            cv2.imshow("Queue Management", frame)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                print("[INFO] Display closed by user.")
                break

        # ── Progress ───────────────────────────────────────────────────────────
        if processed_count % 30 == 0:
            pct = (frame_idx / total_frames * 100) if total_frames > 0 else 0
            print(f"  Frame {frame_idx:>5}/{total_frames} ({pct:5.1f}%) | "
                  f"Queue: {queue_count:>3} | FPS: {proc_fps:5.1f}")

    # ── Cleanup ────────────────────────────────────────────────────────────────
    cap.release()
    writer.release()
    csv_file.close()
    if display:
        cv2.destroyAllWindows()

    elapsed_total = time.time() - t_start
    print("-" * 60)
    print(f"[DONE] Processed {processed_count} frames in {elapsed_total:.1f}s")
    print(f"[DONE] Output video : {output_video}")
    print(f"[DONE] CSV log      : {csv_path}")


if __name__ == "__main__":
    main()
