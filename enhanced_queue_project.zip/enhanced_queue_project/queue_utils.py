"""
queue_utils.py - Helper functions for drawing queue regions and counting people.
"""

import cv2
import numpy as np


def draw_queue_region(frame: np.ndarray, region: list, count: int, threshold: int) -> np.ndarray:
    """
    Draw the queue bounding region on the frame with a color-coded overlay.

    Args:
        frame:     The video frame (BGR numpy array).
        region:    [x1, y1, x2, y2] defining the queue rectangle.
        count:     Current number of people detected inside the region.
        threshold: Alert threshold; region turns red when count >= threshold.

    Returns:
        Annotated frame.
    """
    x1, y1, x2, y2 = region
    color = (0, 0, 220) if count >= threshold else (0, 200, 0)  # Red if over threshold, else green

    # Semi-transparent fill
    overlay = frame.copy()
    cv2.rectangle(overlay, (x1, y1), (x2, y2), color, -1)
    cv2.addWeighted(overlay, 0.15, frame, 0.85, 0, frame)

    # Solid border
    cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)

    # Label background
    label = f"Queue: {count} person{'s' if count != 1 else ''}"
    (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)
    cv2.rectangle(frame, (x1, y1 - th - 12), (x1 + tw + 10, y1), color, -1)
    cv2.putText(frame, label, (x1 + 5, y1 - 6),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2, cv2.LINE_AA)

    return frame


def draw_detections(frame: np.ndarray, detections: list, region: list) -> np.ndarray:
    """
    Draw bounding boxes around each detected person.

    Args:
        frame:      The video frame.
        detections: List of (x1, y1, x2, y2, confidence) tuples for detected people.
        region:     Queue region [x1, y1, x2, y2].

    Returns:
        Annotated frame.
    """
    rx1, ry1, rx2, ry2 = region
    for (bx1, by1, bx2, by2, conf) in detections:
        cx = (bx1 + bx2) / 2
        cy = (by1 + by2) / 2
        in_region = rx1 <= cx <= rx2 and ry1 <= cy <= ry2
        box_color = (0, 140, 255) if in_region else (180, 180, 180)
        cv2.rectangle(frame, (bx1, by1), (bx2, by2), box_color, 2)
        conf_label = f"{conf:.2f}"
        cv2.putText(frame, conf_label, (bx1, by1 - 5),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, box_color, 1, cv2.LINE_AA)
    return frame


def count_people_in_region(detections: list, region: list) -> int:
    """
    Count how many detected people have their centre inside the queue region.

    Args:
        detections: List of (x1, y1, x2, y2, confidence) tuples.
        region:     [x1, y1, x2, y2] queue rectangle.

    Returns:
        Integer count of people inside the region.
    """
    x1, y1, x2, y2 = region
    count = 0
    for (bx1, by1, bx2, by2, _conf) in detections:
        cx = (bx1 + bx2) / 2
        cy = (by1 + by2) / 2
        if x1 <= cx <= x2 and y1 <= cy <= y2:
            count += 1
    return count


def draw_hud(frame: np.ndarray, frame_idx: int, fps: float, total_count: int, alert: bool) -> np.ndarray:
    """
    Draw a heads-up display (HUD) with runtime statistics in the top-right corner.

    Args:
        frame:       The video frame.
        frame_idx:   Current frame number.
        fps:         Processing frames per second.
        total_count: Total people counted so far across all frames.
        alert:       Whether an alert is currently active.

    Returns:
        Annotated frame.
    """
    h, w = frame.shape[:2]
    lines = [
        f"Frame : {frame_idx}",
        f"FPS   : {fps:.1f}",
        f"Total : {total_count}",
    ]
    if alert:
        lines.append("! ALERT !")

    padding = 8
    line_h = 22
    box_w = 160
    box_h = len(lines) * line_h + padding * 2
    bx1, by1 = w - box_w - 10, 10
    bx2, by2 = w - 10, by1 + box_h

    cv2.rectangle(frame, (bx1, by1), (bx2, by2), (30, 30, 30), -1)
    cv2.rectangle(frame, (bx1, by1), (bx2, by2), (100, 100, 100), 1)

    for i, line in enumerate(lines):
        color = (0, 0, 220) if "ALERT" in line else (220, 220, 220)
        cv2.putText(frame, line, (bx1 + padding, by1 + padding + (i + 1) * line_h - 4),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.52, color, 1, cv2.LINE_AA)
    return frame
